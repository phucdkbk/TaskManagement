/* DOMElement.java

	Purpose:
		
	Description:
		
	History:
		Fri Nov 20 17:28:13     2009, Created by tomyeh

Copyright (C) 2009 Potix Corporation. All Rights Reserved.

*/
package _global_;

/**
 * Represents a DOM element.
 * <p>Refer to <a href="http://www.w3schools.com/dom/dom_element.asp">JavaScript Reference</a>
 * for details.
 *
 * @author tomyeh
 */
public class DOMElement {
	private DOMElement() {}
}
