/* Window.java

	Purpose:
		
	Description:
		
	History:
		Thu Jul  8 11:18:35 TST 2010, Created by tomyeh

Copyright (C) 2010 Potix Corporation. All Rights Reserved.

*/
package _global_;

/**
 * Window object representing an open window in a browser.
 * <p>Refer to <a href="http://wwww.w3schools.com/jsref/obj_window.asp">JavaScript Reference</a>.
 * @author tomyeh
 */
public class Window {
}
