/* XMLHttpRequest.java

	Purpose:
		
	Description:
		
	History:
		Mon Jul  5 10:21:13 TST 2010, Created by tomyeh

Copyright (C) 2010 Potix Corporation. All Rights Reserved.

*/
package _global_;

/**
 * The XMLHttpRequest specification defines an API that provides scripted client functionality for transferring data between a client and a server.
 * Refer <a href="http://www.w3schools.com/xml/xml_http.asp">here</a> for details.
 * @author tomyeh
 */
public class XMLHttpRequest {
}
