/* HTMLs.java

	Purpose:
		
	Description:
		
	History:
		Sat Dec 31 12:46:27     2005, Created by tomyeh

Copyright (C) 2004 Potix Corporation. All Rights Reserved.

{{IS_RIGHT
	This program is distributed under LGPL Version 3.0 in the hope that
	it will be useful, but WITHOUT ANY WARRANTY.
}}IS_RIGHT
*/
package org.zkoss.xml;

/** @deprecated As of release 6.0.0, replaced with {@link org.zkoss.html.HTMLs}.
 *
 * @author tomyeh
 */
public class HTMLs extends org.zkoss.html.HTMLs {
}
