* Copy war.libs.all to war.libs if you want to embed ZK libraries
  into your Web application.
* Copy war.libs.minimal to war.libs if you installed ZK libraires
  into the shared directory of the Web server.
 