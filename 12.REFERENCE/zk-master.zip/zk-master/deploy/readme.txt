Deployment Description
----------------------

It describes how to deploy jar and war into tomcat.

server.libs
	Specifies jar files that will be copied to tomcat/shared

ear.libs
	Specifies war files that will be copied to tomcat/webapps
