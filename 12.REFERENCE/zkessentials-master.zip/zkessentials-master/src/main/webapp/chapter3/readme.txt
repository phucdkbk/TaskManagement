please refer to
http://books.zkoss.org/wiki/ZK_Essentials/Chapter_3:_User_Interface_and_Layout