Please refer to 
http://books.zkoss.org/wiki/ZK_Essentials/Chapter_4:_Controlling_Components