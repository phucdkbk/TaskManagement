Please refer to
http://books.zkoss.org/wiki/ZK_Essentials/Chapter_6:_Implementing_CRUD