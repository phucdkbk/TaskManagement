Please refer to 
http://books.zkoss.org/wiki/ZK_Essentials/Chapter_8:_Authentication