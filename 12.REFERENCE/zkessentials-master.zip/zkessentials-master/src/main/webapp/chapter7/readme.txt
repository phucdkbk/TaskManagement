Please refer to
http://books.zkoss.org/wiki/ZK_Essentials/Chapter_7:_Navigation_and_Templating