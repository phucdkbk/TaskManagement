Please refer to
http://books.zkoss.org/wiki/ZK_Essentials/Chapter_5:_Handling_User_Input